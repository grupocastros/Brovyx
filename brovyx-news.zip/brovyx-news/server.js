import express from "express";
import { Parser } from 'rss-parser';
import axios from 'axios';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config();

const app = express();
const parser = new Parser();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD_PLAIN = process.env.ADMIN_PASSWORD_PLAIN || "YOUR_ADMIN_PASSWORD";

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

const SOURCES = [
  { name: "Wired", type: "rss", url: "https://www.wired.com/feed/rss" },
  { name: "ZDNet", type: "rss", url: "https://www.zdnet.com/news/rss.xml" },
  { name: "CNET", type: "rss", url: "https://www.cnet.com/rss/news/" },
  { name: "The Verge", type: "rss", url: "https://www.theverge.com/rss/index.xml" },
  { name: "TechCrunch", type: "rss", url: "http://feeds.feedburner.com/Techcrunch" },
  { name: "NewsAPI", type: "api", url: `https://newsapi.org/v2/top-headlines?category=technology&apiKey=${process.env.NEWSAPI_KEY}` }
];

async function fetchAllNews() {
  const results = await Promise.allSettled(
    SOURCES.map(async (source) => {
      try {
        if (source.type === "rss") {
          const feed = await parser.parseURL(source.url);
          return feed.items.map(item => ({
            id: item.guid || item.link,
            title: item.title,
            excerpt: item.contentSnippet || item.description,
            link: item.link,
            image: item.enclosure?.url || item['media:content']?.url || "https://placehold.co/400x250?text=No+Image",
            source: source.name,
            publishedAt: item.pubDate,
            author: item.creator || "Unknown"
          }));
        } else if (source.type === "api") {
          const response = await axios.get(source.url);
          return (response.data.articles || []).map(article => ({
            id: article.url,
            title: article.title,
            excerpt: article.description,
            link: article.url,
            image: article.urlToImage || "https://placehold.co/400x250?text=No+Image",
            source: source.name,
            publishedAt: article.publishedAt,
            author: article.author || "Unknown"
          }));
        }
      } catch (err) {
        console.error(`Erro ao buscar ${source.name}:`, err.message);
        return [];
      }
    })
  );
  return results.filter(r => r.status === 'fulfilled').flatMap(r => r.value).filter(Boolean);
}

app.get('/api/news', async (req, res) => {
  try {
    const news = await fetchAllNews();
    res.json(news.slice(0, 50));
  } catch (error) {
    res.status(500).json({ error: 'Falha ao buscar notícias' });
  }
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (username === 'developer' && password === ADMIN_PASSWORD_PLAIN) {
    res.json({ success: true, token: 'dev-auth-token' });
  } else {
    res.status(401).json({ error: 'Credenciais inválidas' });
  }
});

app.listen(PORT, () => {
  console.log(`Brovyx News rodando na porta ${PORT}`);
});