async function loadNews() {
  try {
    const response = await fetch('/api/news');
    const news = await response.json();
    const container = document.getElementById('news-container');
    container.innerHTML = '';

    news.forEach(article => {
      const date = new Date(article.publishedAt).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' });
      const card = document.createElement('article');
      card.className = 'news-card bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300';
      card.innerHTML = `
        <img src="${article.image}" alt="${article.title}" class="w-full h-48 object-cover">
        <div class="text-xs font-semibold text-blue-600 uppercase tracking-wide">${article.source}</div>
        <div class="font-bold text-lg mb-2 px-4 pt-4">${article.title}</div>
        <p class="text-gray-600 text-sm px-4">${article.excerpt}</p>
        <div class="text-xs text-gray-500 px-4">${date}</div>
        <a href="${article.link}" target="_blank" class="block text-center mt-4 bg-blue-600 text-white py-2 rounded">Ler Mais</a>
      `;
      container.appendChild(card);
    });
  } catch (error) {
    document.getElementById('news-container').innerHTML = '<p class="text-center text-red-500">Erro ao carregar notícias.</p>';
  }
}
window.onload = loadNews;